package com.ds;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterUser
 */
@WebServlet("/RegisterUser")
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public RegisterUser() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public static byte[] getPassword(String input) throws NoSuchAlgorithmException
	{
	    MessageDigest md = MessageDigest.getInstance("SHA-256");

	    
	    return md.digest(input.getBytes(StandardCharsets.UTF_8));
	}
	 
	public static String toHex(byte[] hash)
	{
	    BigInteger number = new BigInteger(1, hash);

	    StringBuilder hexString = new StringBuilder(number.toString(16));

	    while (hexString.length() < 64)
	    {
	        hexString.insert(0, '0');
	    }
	

	    return hexString.toString();
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		System.out.println("Register User Received...");
		System.out.println("Registering driver...");    
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Driver registered....");
		
		System.out.println("Trying to connect to the DB");
		Connection conn;
	
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/medical", "root", "Yash_1408");
			System.out.println("Connected to the DB : "+conn);
			System.out.println("trying to make a statment kartoyyyyy");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String contact =  request.getParameter("contNumber") ;
			String country = request.getParameter("country");
			String dateofbirth = request.getParameter("dob");
			String password = request.getParameter("newpass1");
			String encryptPass = toHex(getPassword(password));
					
			System.out.println("Username " + email);
			System.out.println("Password Before " + password);
			System.out.println("Password After " + encryptPass);
					
			PreparedStatement st = conn.prepareStatement("INSERT INTO LOGININFO (NAME,USERNAME,PASSWORD) VALUES (?,?,?);");
			st.setString(1, name);
			st.setString(2, email);
			st.setString(3, encryptPass);
			
			int row = st.executeUpdate();
			System.out.println("Row in Logininfo " + row);
			System.out.println("Database updated succesfully...");

			PreparedStatement ps = conn.prepareStatement("INSERT INTO USERINFO (name,contactnumber,country,dateofbirth) VALUES (?,?,?,?);");
			ps.setString(1, name);
			ps.setString(2, contact);
			ps.setString(3, country);
			ps.setString(4, dateofbirth);
			
			int rows = ps.executeUpdate();
			System.out.println("Rows  in userinfo" + rows);
			
			RequestDispatcher rd = request.getRequestDispatcher("/dashboard.html");
			rd.forward(request, response);
			}
		catch (SQLException | NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}




