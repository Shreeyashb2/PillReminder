package com.ds;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserDetailsRev
 */
@WebServlet("/UserDetailsRev")
public class UserDetailsRev extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserDetailsRev() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		System.out.println("Registering user Details");    
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Driver registered....");
		
		System.out.println("Trying to connect to the DB");
		Connection conn;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/medical", "root", "Yash_1408");
			System.out.println("Connected to the DB : "+conn);
			System.out.println("trying to connect to userinfo...");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			int contact  = Integer.parseInt(request.getParameter("contNumber"));
			String country = request.getParameter("country");
			String dateofbirth = request.getParameter("dob");
			int weight = Integer.parseInt(request.getParameter("weight"));
			int height = Integer.parseInt(request.getParameter("height"));
			
		
			
			Statement st1 = conn.createStatement();
			PreparedStatement st = conn.prepareStatement("INSERT INTO USERINFO  VALUES (?,?,?,?,?,?,?);");
			st.setString(1, name);
			st.setString(2, email);
			st.setInt(3, contact);
			st.setString(4, country);
			st.setString(5, dateofbirth);
			st.setInt(6, weight);
			st.setInt(7, height);
			
			int row = st.executeUpdate();
			System.out.println("Rows " + row);
			System.out.println("Database updated succesfully...");
			
			RequestDispatcher rd = request.getRequestDispatcher("/dashboard.html");
			rd.forward(request, response);
			}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
