package com.ds;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Servlet implementation class Register
 */
@WebServlet("/LoginValidation")
public class LoginValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginValidation() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public static byte[] getPassword(String input) throws NoSuchAlgorithmException
	{
	    MessageDigest md = MessageDigest.getInstance("SHA-256");

	    
	    return md.digest(input.getBytes(StandardCharsets.UTF_8));
	}
	 
	public static String toHex(byte[] hash)
	{
	    BigInteger number = new BigInteger(1, hash);

	    StringBuilder hexString = new StringBuilder(number.toString(16));

	    while (hexString.length() < 64)
	    {
	        hexString.insert(0, '0');
	    }
	

	    return hexString.toString();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Registering driver...");    
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Driver registered....");
		
		System.out.println("Trying to connect to the DB");
		Connection conn;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/medical", "root", "Yash_1408");
			System.out.println("Connected to the DB : "+conn);
			System.out.println("trying to make a statment in medical...");
			String username = request.getParameter("username");
			String password =request.getParameter("password");
			String encryptPass = toHex(getPassword(password));
			
			
			System.out.println("username " + username);
			System.out.println("Encrypt Password " + encryptPass);
			
		
			
			ResultSet rs1 = conn.createStatement().executeQuery("SELECT PASSWORD FROM  LOGININFO WHERE USERNAME='" + username + "';");
			if (rs1.next() && rs1.getString(1).equals(encryptPass)) {
				System.out.println("Getting Password " + rs1.getString(1));
				HttpSession session=request.getSession();  
		        session.setAttribute("name",username);
		        if (session.getAttribute("name") != null) {
		        	RequestDispatcher rd = request.getRequestDispatcher("/dashboard.jsp");
					rd.forward(request, response);
		        }
		        else {
		        	System.out.println("Else Statement... Session not creating...");
		        }
				
			}
			else {
				PrintWriter pw = response.getWriter();
				pw.println("<script>alert('Please Provide valid Credentials')  </script>");
				response.sendRedirect("login.html");
				
				 			
			}
		}
		catch (SQLException | NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
			
			
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}