function resetPass(){
		var email = document.getElementById("useremail").value
		var isgood = true;
		if (email == ""){
			document.getElementById("usererr").innerHTML = "Username cannot be blanked";
			isgood = false;
		}
		var pass1 = document.getElementById("userpass1").value
		var pass2 = document.getElementById("userpass2").value
		if (pass1 == ""){
			isgood = false;
			document.getElementById("passerr1").innerHTML = "Password cannot be blanked";
		}
		if(pass2 == ""){
			isgood = false;
			document.getElementById("passerr2").innerHTML = "Confirm Password cannot be blanked";
		}
		return isgood;
	}
	function clearUserErr(){document.getElementById("usererr").innerHTML="";console.log("Clearing user Error");}
	function clearPassErr(){document.getElementById("passerr1").innerHTML="";console.log("Clearing Password Error");}