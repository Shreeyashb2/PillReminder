function validateUser(){
		var username = document.getElementById("username").value
		if (username == ""){
			//document.getElementById("userErr").innerHTML = "Username cannot be blanked";
			alert("username cannot be blanked...");
			return false;
		}
		var password = document.getElementById("userpass").value
		if (password== ""){
			alert("Password cannot be blanked...");
			//document.getElementById("passErr").innerHTML = "Password cannot be blanked";
			return false;
		}
		return true;
	}
	function clearUserErr(){document.getElementById("userErr").innerHTML="";console.log("Clearing user Error");}
	function clearPassErr(){document.getElementById("passErr").innerHTML="";console.log("Clearing Password Error");}