function validatePassword(){
	var pass1 = document.getElementById("newpass1").value
	console.log("ValidatePassword Paryant aali gaadi...")
	var pass2 = document.getElementById("newpass2").value
	if(pass1 == pass2){
		return true;
		
	}
	else{
		alert("Please Write Correct Password");
		return false;
	}
	
}